import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().unique(),
  image: text("image").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  whatsapp: text("whatsapp").notNull(),
  countryCode: text("country_code").notNull(),
  phoneNumber: text("phone_number").notNull(),
  approved: boolean("approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostSchema = createInsertSchema(posts).pick({
  image: true,
  description: true,
  price: true,
  whatsapp: true,
  countryCode: true,
  phoneNumber: true,
}).extend({
  postId: z.string().optional(),
});

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
