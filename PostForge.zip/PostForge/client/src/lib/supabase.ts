export const SUPABASE_CONFIG = {
  url: 'https://zuipgkmahwbvqigtnvrb.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1aXBna21haHdidnFpZ3RudnJiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4NzEwNDMsImV4cCI6MjA2OTQ0NzA0M30.H0RjREGM7Fw7XkfEyI99yCfDZ4ZxCmWyxv2b9Isiz8w'
};

export const COUNTRY_CODES = [
  { value: '+234', label: '🇳🇬 Nigeria (+234)' },
  { value: '+233', label: '🇬🇭 Ghana (+233)' },
  { value: '+1', label: '🇺🇸 USA (+1)' },
  { value: '+27', label: '🇿🇦 South Africa (+27)' },
  { value: '+91', label: '🇮🇳 India (+91)' },
  { value: '+44', label: '🇬🇧 UK (+44)' },
];

export const BACKGROUND_IMAGES = [
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080',
  'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080',
  'https://images.unsplash.com/photo-1519904981063-b0cf448d479e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080',
  'https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080'
];

export const PASSWORD = 'teamcode12';
