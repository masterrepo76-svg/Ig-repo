import { useState, useRef, useCallback } from 'react';

export interface ImageEditorState {
  brightness: number;
  rotation: number;
  cropData: {
    x: number;
    y: number;
    width: number;
    height: number;
  } | null;
  originalImage: string | null;
  editedImage: string | null;
}

export function useImageEditor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [editorState, setEditorState] = useState<ImageEditorState>({
    brightness: 100,
    rotation: 0,
    cropData: null,
    originalImage: null,
    editedImage: null,
  });

  const loadImage = useCallback((imageUrl: string) => {
    setEditorState(prev => ({
      ...prev,
      originalImage: imageUrl,
      editedImage: imageUrl,
    }));
    // Apply initial filters after loading
    setTimeout(() => applyFilters(), 100);
  }, []);

  const adjustBrightness = useCallback((value: number) => {
    setEditorState(prev => ({
      ...prev,
      brightness: value,
    }));
  }, []);

  const rotateImage = useCallback((degrees: number) => {
    setEditorState(prev => ({
      ...prev,
      rotation: (prev.rotation + degrees) % 360,
    }));
  }, []);

  const applyFilters = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !editorState.originalImage) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      ctx.save();
      
      // Apply rotation
      if (editorState.rotation !== 0) {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((editorState.rotation * Math.PI) / 180);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);
      }
      
      // Apply brightness filter
      ctx.filter = `brightness(${editorState.brightness}%)`;
      
      ctx.drawImage(img, 0, 0);
      ctx.restore();
      
      const editedImageUrl = canvas.toDataURL();
      setEditorState(prev => ({
        ...prev,
        editedImage: editedImageUrl,
      }));
    };
    img.src = editorState.originalImage;
  }, [editorState.brightness, editorState.rotation, editorState.originalImage]);

  const resetEditor = useCallback(() => {
    setEditorState({
      brightness: 100,
      rotation: 0,
      cropData: null,
      originalImage: null,
      editedImage: null,
    });
  }, []);

  const saveEdit = useCallback(() => {
    return editorState.editedImage || editorState.originalImage;
  }, [editorState.editedImage, editorState.originalImage]);

  return {
    editorState,
    canvasRef,
    loadImage,
    adjustBrightness,
    rotateImage,
    applyFilters,
    resetEditor,
    saveEdit,
  };
}
