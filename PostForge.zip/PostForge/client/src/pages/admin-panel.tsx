import { useState } from 'react';
import { HamburgerMenu } from '@/components/hamburger-menu';
import { UploadTab } from '@/components/upload-tab';
import { ManagementTab } from '@/components/management-tab';
import { AboutTab } from '@/components/about-tab';
import { Button } from '@/components/ui/button';
import { BACKGROUND_IMAGES } from '@/lib/supabase';
import { Palette } from 'lucide-react';

export default function AdminPanel() {
  const [currentTab, setCurrentTab] = useState(1);
  const [backgroundIndex, setBackgroundIndex] = useState(0);

  const switchBackground = () => {
    const newIndex = (backgroundIndex + 1) % BACKGROUND_IMAGES.length;
    setBackgroundIndex(newIndex);
    document.body.style.backgroundImage = `url('${BACKGROUND_IMAGES[newIndex]}')`;
  };

  const renderTabContent = () => {
    switch (currentTab) {
      case 1:
        return <UploadTab />;
      case 2:
        return <ManagementTab />;
      case 3:
        return <AboutTab />;
      default:
        return <UploadTab />;
    }
  };

  return (
    <div data-testid="admin-panel" className="min-h-screen p-4 lg:p-8">
      <HamburgerMenu onTabChange={setCurrentTab} currentTab={currentTab} />
      
      {/* Background Theme Switcher */}
      <Button
        data-testid="theme-switcher"
        onClick={switchBackground}
        className="fixed top-4 right-4 z-30 p-3 bg-gray-800 hover:bg-gray-700 text-white rounded-lg shadow-lg"
      >
        <Palette className="w-5 h-5 text-amber-400" />
      </Button>

      {/* Main Content Container */}
      <div className="max-w-4xl mx-auto">
        <div data-testid={`tab-content-${currentTab}`} className="animate-fade-in">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}
