import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { COUNTRY_CODES } from '@/lib/supabase';
import { Facebook, MessageCircle, Send, AlignLeft, Tag } from 'lucide-react';

interface PostPreviewProps {
  imageUrl: string;
  onPublish: (postData: PostData) => void;
}

export interface PostData {
  image: string;
  description: string;
  price: number;
  countryCode: string;
  phoneNumber: string;
  whatsapp: string;
}

export function PostPreview({ imageUrl, onPublish }: PostPreviewProps) {
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [countryCode, setCountryCode] = useState('+234');
  const [phoneNumber, setPhoneNumber] = useState('');

  const generateWhatsAppLink = () => {
    if (!phoneNumber) return '#';
    const message = encodeURIComponent(`I LOVE THIS ORDER - ${description || 'this item'} - HOW CAN I GET it?`);
    return `https://wa.me/${countryCode.replace('+', '')}${phoneNumber}?text=${message}`;
  };

  const handlePublish = () => {
    const postData: PostData = {
      image: imageUrl,
      description,
      price: parseInt(price) || 0,
      countryCode,
      phoneNumber,
      whatsapp: `${countryCode}${phoneNumber}`,
    };
    onPublish(postData);
  };

  return (
    <div data-testid="post-preview" className="bg-gray-700 rounded-xl p-6">
      <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
        <Facebook className="w-5 h-5 text-blue-500 mr-2" />
        Preview Post Display
      </h3>

      {/* Facebook-Style Post Preview */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-6">
        <div className="p-4 border-b">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
              <i className="fas fa-store text-white"></i>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Your Store</h4>
              <p className="text-sm text-gray-500">Just now</p>
            </div>
          </div>
        </div>

        <div data-testid="post-content">
          <div className="p-4">
            <p data-testid="preview-description" className="text-gray-800 mb-2">
              {description || 'Your post description will appear here...'}
            </p>
            <p data-testid="preview-price" className="text-2xl font-bold text-emerald-600 mb-2">
              ₦{price || '0'}
            </p>
            <a
              data-testid="preview-whatsapp"
              href={generateWhatsAppLink()}
              className="inline-flex items-center text-emerald-600 hover:text-emerald-700 font-medium"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Contact via WhatsApp
            </a>
          </div>
          <img
            data-testid="preview-image"
            src={imageUrl}
            alt="Post Image"
            className="w-full h-64 object-cover"
          />
        </div>
      </div>

      {/* Form Fields */}
      <div className="space-y-4 mb-8">
        <div>
          <label className="block text-white font-semibold mb-2 flex items-center">
            <AlignLeft className="w-4 h-4 text-blue-400 mr-2" />
            Description
          </label>
          <Textarea
            data-testid="description-input"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter your post description..."
            className="bg-gray-600 text-white border-gray-500 focus:border-blue-400"
            rows={3}
          />
        </div>

        <div>
          <label className="block text-white font-semibold mb-2 flex items-center">
            <Tag className="w-4 h-4 text-emerald-400 mr-2" />
            Price (Numbers Only)
          </label>
          <Input
            data-testid="price-input"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="150"
            className="bg-gray-600 text-white border-gray-500 focus:border-blue-400"
          />
        </div>

        <div>
          <label className="block text-white font-semibold mb-2 flex items-center">
            <MessageCircle className="w-4 h-4 text-emerald-400 mr-2" />
            WhatsApp Contact
          </label>
          <div className="flex space-x-2">
            <Select value={countryCode} onValueChange={setCountryCode}>
              <SelectTrigger data-testid="country-select" className="w-48 bg-gray-600 text-white border-gray-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {COUNTRY_CODES.map((country) => (
                  <SelectItem key={country.value} value={country.value}>
                    {country.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              data-testid="phone-input"
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="9162835238"
              className="flex-1 bg-gray-600 text-white border-gray-500 focus:border-blue-400"
            />
          </div>
        </div>
      </div>

      {/* Post Button */}
      <div className="text-center">
        <Button
          data-testid="publish-post"
          onClick={handlePublish}
          className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white px-12 py-4 text-xl font-bold shadow-2xl animate-pulse"
          disabled={!description || !price || !phoneNumber}
        >
          <Send className="w-5 h-5 mr-3" />
          POST NOW
        </Button>
        <p className="text-gray-400 mt-2">Publish Your Post</p>
      </div>
    </div>
  );
}
