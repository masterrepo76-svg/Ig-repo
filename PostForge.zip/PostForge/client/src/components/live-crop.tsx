import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';

interface LiveCropProps {
  imageUrl: string;
  onCropComplete: (croppedImageUrl: string) => void;
  onCancel: () => void;
}

export function LiveCrop({ imageUrl, onCropComplete, onCancel }: LiveCropProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [cropArea, setCropArea] = useState({
    x: 50,
    y: 50,
    width: 200,
    height: 200,
  });

  useEffect(() => {
    if (imageRef.current) {
      imageRef.current.onload = () => {
        const img = imageRef.current!;
        const initialSize = Math.min(img.width, img.height) * 0.6;
        setCropArea({
          x: (img.width - initialSize) / 2,
          y: (img.height - initialSize) / 2,
          width: initialSize,
          height: initialSize,
        });
      };
    }
  }, [imageUrl]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    e.preventDefault();
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !imageRef.current) return;

    const rect = imageRef.current.getBoundingClientRect();
    const scaleX = imageRef.current.naturalWidth / rect.width;
    const scaleY = imageRef.current.naturalHeight / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    setCropArea(prev => ({
      ...prev,
      x: Math.max(0, Math.min(x - prev.width / 2, imageRef.current!.naturalWidth - prev.width)),
      y: Math.max(0, Math.min(y - prev.height / 2, imageRef.current!.naturalHeight - prev.height)),
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const applyCrop = () => {
    if (!canvasRef.current || !imageRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = cropArea.width;
    canvas.height = cropArea.height;

    ctx.drawImage(
      imageRef.current,
      cropArea.x,
      cropArea.y,
      cropArea.width,
      cropArea.height,
      0,
      0,
      cropArea.width,
      cropArea.height
    );

    const croppedImageUrl = canvas.toDataURL('image/jpeg', 0.9);
    onCropComplete(croppedImageUrl);
  };

  const presetCrops = [
    { label: 'Square', ratio: 1 },
    { label: '4:3', ratio: 4/3 },
    { label: '16:9', ratio: 16/9 },
    { label: '3:4', ratio: 3/4 },
  ];

  const applyPreset = (ratio: number) => {
    if (!imageRef.current) return;

    const img = imageRef.current;
    let width, height;

    if (ratio === 1) {
      // Square
      const size = Math.min(img.naturalWidth, img.naturalHeight) * 0.8;
      width = height = size;
    } else if (ratio > 1) {
      // Landscape
      width = img.naturalWidth * 0.8;
      height = width / ratio;
      if (height > img.naturalHeight * 0.8) {
        height = img.naturalHeight * 0.8;
        width = height * ratio;
      }
    } else {
      // Portrait
      height = img.naturalHeight * 0.8;
      width = height * ratio;
      if (width > img.naturalWidth * 0.8) {
        width = img.naturalWidth * 0.8;
        height = width / ratio;
      }
    }

    setCropArea({
      x: (img.naturalWidth - width) / 2,
      y: (img.naturalHeight - height) / 2,
      width,
      height,
    });
  };

  return (
    <div data-testid="live-crop" className="bg-gray-700 rounded-xl p-6">
      <h3 className="text-xl font-semibold text-white mb-4">Live Crop Your Image</h3>
      
      {/* Crop Presets */}
      <div className="mb-4">
        <p className="text-white mb-2">Quick Crop Presets:</p>
        <div className="flex gap-2 flex-wrap">
          {presetCrops.map((preset) => (
            <Button
              key={preset.label}
              data-testid={`preset-${preset.label.toLowerCase()}`}
              onClick={() => applyPreset(preset.ratio)}
              variant="secondary"
              size="sm"
              className="bg-blue-500 text-white hover:bg-blue-600"
            >
              {preset.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Image with Crop Overlay */}
      <div className="relative mb-6 bg-gray-800 rounded-lg overflow-hidden">
        <img
          ref={imageRef}
          src={imageUrl}
          alt="Crop Preview"
          className="max-w-full h-auto block"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
        />
        
        {/* Crop Overlay */}
        {imageRef.current && (
          <div
            className="absolute border-2 border-white bg-white bg-opacity-20"
            style={{
              left: `${(cropArea.x / imageRef.current.naturalWidth) * 100}%`,
              top: `${(cropArea.y / imageRef.current.naturalHeight) * 100}%`,
              width: `${(cropArea.width / imageRef.current.naturalWidth) * 100}%`,
              height: `${(cropArea.height / imageRef.current.naturalHeight) * 100}%`,
              pointerEvents: 'none',
            }}
          >
            <div className="absolute inset-0 border border-dashed border-white"></div>
          </div>
        )}
      </div>

      {/* Instructions */}
      <p className="text-gray-300 mb-4 text-center">
        Click and drag on the image to move the crop area. Use presets for common ratios.
      </p>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button
          data-testid="apply-crop"
          onClick={applyCrop}
          className="bg-emerald-500 hover:bg-emerald-600 text-white flex-1"
        >
          Apply Crop
        </Button>
        <Button
          data-testid="cancel-crop"
          onClick={onCancel}
          variant="destructive"
          className="flex-1"
        >
          Cancel
        </Button>
      </div>

      {/* Hidden canvas for processing */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}