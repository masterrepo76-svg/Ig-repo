import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useImageEditor } from '@/hooks/use-image-editor';
import { LiveCrop } from './live-crop';
import { Crop, Sun, RotateCcw, RotateCw, FlipVertical, Save, X, ArrowLeft } from 'lucide-react';

interface ImageEditorProps {
  imageUrl: string;
  onSave: (editedImageUrl: string) => void;
  onCancel: () => void;
}

export function ImageEditor({ imageUrl, onSave, onCancel }: ImageEditorProps) {
  const [showCrop, setShowCrop] = useState(false);
  const [currentImage, setCurrentImage] = useState(imageUrl);
  
  const {
    editorState,
    canvasRef,
    loadImage,
    adjustBrightness,
    rotateImage,
    applyFilters,
    saveEdit,
  } = useImageEditor();

  useEffect(() => {
    loadImage(currentImage);
  }, [currentImage, loadImage]);

  // Apply filters whenever brightness or rotation changes
  useEffect(() => {
    applyFilters();
  }, [editorState.brightness, editorState.rotation, applyFilters]);

  const handleSave = () => {
    const editedUrl = saveEdit();
    if (editedUrl) {
      onSave(editedUrl);
    }
  };

  const handleCropComplete = (croppedImageUrl: string) => {
    setCurrentImage(croppedImageUrl);
    setShowCrop(false);
  };

  if (showCrop) {
    return (
      <div>
        <Button
          data-testid="back-from-crop"
          onClick={() => setShowCrop(false)}
          variant="ghost"
          className="mb-4 text-white hover:bg-gray-600"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Editor
        </Button>
        <LiveCrop
          imageUrl={currentImage}
          onCropComplete={handleCropComplete}
          onCancel={() => setShowCrop(false)}
        />
      </div>
    );
  }



  return (
    <div data-testid="image-editor" className="bg-gray-700 rounded-xl p-6">
      <Button
        data-testid="back-from-editor"
        onClick={onCancel}
        variant="ghost"
        className="mb-4 text-white hover:bg-gray-600"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back
      </Button>
      
      <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
        <Crop className="w-5 h-5 text-blue-400 mr-2" />
        Edit Your Image
      </h3>

      {/* Image Preview */}
      <div className="bg-gray-800 rounded-lg p-4 mb-6">
        <img
          data-testid="image-preview"
          src={editorState.editedImage || currentImage}
          alt="Image Preview"
          className="max-w-full h-64 object-contain mx-auto rounded"
        />
        <canvas ref={canvasRef} className="hidden" />
      </div>

      {/* Editing Tools */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Live Crop Tool */}
        <div className="bg-gray-600 rounded-lg p-4">
          <h4 className="font-semibold text-white mb-3 flex items-center">
            <Crop className="w-4 h-4 text-emerald-400 mr-2" />
            Live Crop Tool
          </h4>
          <Button
            data-testid="open-crop-tool"
            onClick={() => setShowCrop(true)}
            className="w-full bg-emerald-500 text-white hover:bg-emerald-600"
          >
            <Crop className="w-4 h-4 mr-2" />
            Open Live Crop Editor
          </Button>
        </div>

        {/* Brightness Control */}
        <div className="bg-gray-600 rounded-lg p-4">
          <h4 className="font-semibold text-white mb-3 flex items-center">
            <Sun className="w-4 h-4 text-amber-400 mr-2" />
            Adjust Brightness
          </h4>
          <div className="space-y-2">
            <Slider
              data-testid="brightness-slider"
              value={[editorState.brightness]}
              onValueChange={(value) => adjustBrightness(value[0])}
              min={0}
              max={200}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-400">
              <span>Dark</span>
              <span>Normal</span>
              <span>Bright</span>
            </div>
          </div>
        </div>

        {/* Rotation Tools */}
        <div className="bg-gray-600 rounded-lg p-4">
          <h4 className="font-semibold text-white mb-3 flex items-center">
            <RotateCcw className="w-4 h-4 text-purple-400 mr-2" />
            Rotate Options
          </h4>
          <div className="grid grid-cols-3 gap-2">
            <Button
              data-testid="rotate-left"
              onClick={() => rotateImage(-90)}
              variant="secondary"
              size="sm"
              className="bg-purple-500 text-white hover:bg-purple-600"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button
              data-testid="rotate-right"
              onClick={() => rotateImage(90)}
              variant="secondary"
              size="sm"
              className="bg-purple-500 text-white hover:bg-purple-600"
            >
              <RotateCw className="w-4 h-4" />
            </Button>
            <Button
              data-testid="flip-vertical"
              onClick={() => rotateImage(180)}
              variant="secondary"
              size="sm"
              className="bg-purple-500 text-white hover:bg-purple-600"
            >
              <FlipVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button
          data-testid="save-edit"
          onClick={handleSave}
          className="bg-emerald-500 hover:bg-emerald-600 text-white flex-1"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Edit & Continue
        </Button>
        <Button
          data-testid="cancel-edit"
          onClick={onCancel}
          variant="destructive"
          className="flex-1"
        >
          <X className="w-4 h-4 mr-2" />
          Exit Without Saving
        </Button>
      </div>
    </div>
  );
}
