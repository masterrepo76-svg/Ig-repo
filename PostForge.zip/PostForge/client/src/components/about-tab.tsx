import { Button } from '@/components/ui/button';
import { Info, Code, Mail, MessageCircle, Users } from 'lucide-react';

export function AboutTab() {
  const supporters = [
    { name: 'Alex Johnson', role: 'UI/UX Advisor', color: 'bg-blue-500' },
    { name: 'Sarah Chen', role: 'Quality Tester', color: 'bg-emerald-500' },
    { name: 'Mike Wilson', role: 'Beta Tester', color: 'bg-purple-500' },
    { name: 'Lisa Brown', role: 'Content Reviewer', color: 'bg-amber-500' },
    { name: 'David Kim', role: 'Security Advisor', color: 'bg-red-500' },
    { name: 'Emma Davis', role: 'Performance Analyst', color: 'bg-indigo-500' },
    { name: 'Ryan Taylor', role: 'System Tester', color: 'bg-pink-500' },
    { name: 'Grace Lee', role: 'Documentation', color: 'bg-teal-500' },
  ];

  return (
    <div data-testid="about-tab" className="glass-effect rounded-2xl p-6 lg:p-8 shadow-2xl">
      <div className="text-center mb-8">
        <div className="w-24 h-24 mx-auto bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center mb-4">
          <Info className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-4">About Admin Website</h2>
      </div>

      {/* Website Description */}
      <div className="bg-gray-700 rounded-xl p-6 mb-8">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Info className="w-5 h-5 text-blue-400 mr-2" />
          What This Website Does
        </h3>
        <p className="text-gray-300 leading-relaxed">
          This admin panel is a powerful content management system designed for easy post creation and management. 
          It allows administrators to upload images, edit them with professional tools, create engaging social media-style previews, 
          and manage posts with approval workflows. The system integrates with Supabase for reliable data storage and 
          provides a seamless experience for content creators and administrators.
        </p>
      </div>

      {/* Developer Info */}
      <div className="bg-gray-700 rounded-xl p-6 mb-8">
        <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
          <Code className="w-5 h-5 text-emerald-400 mr-2" />
          Developer Information
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-gray-600 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-3">Lead Developer</h4>
            <p className="text-emerald-400 font-bold text-lg mb-2">VENOM MD</p>
            <div className="space-y-2">
              <Button
                data-testid="email-contact"
                asChild
                variant="ghost"
                className="w-full justify-start p-0 h-auto text-gray-300 hover:text-white"
              >
                <a href="mailto:masterrepo76@gmail.com" className="flex items-center">
                  <Mail className="w-4 h-4 text-red-400 mr-2" />
                  masterrepo76@gmail.com
                </a>
              </Button>
              <Button
                data-testid="whatsapp-contact"
                asChild
                variant="ghost"
                className="w-full justify-start p-0 h-auto text-gray-300 hover:text-white"
              >
                <a href="https://wa.me/2349162835238?text=FROM%20ADMIN%20WEBSITE" className="flex items-center">
                  <MessageCircle className="w-4 h-4 text-emerald-400 mr-2" />
                  +234 916 283 5238
                </a>
              </Button>
            </div>
          </div>
          <div className="bg-gray-600 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-3">Co-Developer</h4>
            <p className="text-blue-400 font-bold text-lg mb-2">SURBU-ER</p>
            <p className="text-gray-400 text-sm">Full-stack development and system architecture</p>
          </div>
        </div>
      </div>

      {/* Supporters Section */}
      <div className="bg-gray-700 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
          <Users className="w-5 h-5 text-purple-400 mr-2" />
          Project Supporters
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {supporters.map((supporter, index) => (
            <div
              key={index}
              data-testid={`supporter-${index}`}
              className="bg-gray-600 rounded-lg p-4 text-center"
            >
              <div className={`w-12 h-12 ${supporter.color} rounded-full mx-auto mb-2 flex items-center justify-center`}>
                <Users className="w-6 h-6 text-white" />
              </div>
              <p className="text-white font-medium text-sm">{supporter.name}</p>
              <p className="text-gray-400 text-xs">{supporter.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
