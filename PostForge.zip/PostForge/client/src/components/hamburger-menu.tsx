import { useState } from 'react';
import { Menu, Upload, Settings, Info } from 'lucide-react';

interface HamburgerMenuProps {
  onTabChange: (tab: number) => void;
  currentTab: number;
}

export function HamburgerMenu({ onTabChange, currentTab }: HamburgerMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  const handleTabClick = (tab: number) => {
    onTabChange(tab);
    setIsOpen(false);
  };

  return (
    <>
      <button
        data-testid="menu-toggle"
        onClick={toggleMenu}
        className="fixed top-4 left-4 z-50 p-3 bg-gray-800 text-white rounded-lg shadow-lg hover:bg-gray-700 transition-colors"
      >
        <Menu className="w-6 h-6" />
      </button>

      <div
        data-testid="side-menu"
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-gray-900 text-white transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-8 text-blue-400">Admin Panel</h2>
          <nav className="space-y-4">
            <button
              data-testid="tab-upload"
              onClick={() => handleTabClick(1)}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center space-x-3 ${
                currentTab === 1 ? 'bg-gray-700' : 'hover:bg-gray-800'
              }`}
            >
              <Upload className="w-5 h-5 text-emerald-400" />
              <span>Upload Content</span>
            </button>
            <button
              data-testid="tab-management"
              onClick={() => handleTabClick(2)}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center space-x-3 ${
                currentTab === 2 ? 'bg-gray-700' : 'hover:bg-gray-800'
              }`}
            >
              <Settings className="w-5 h-5 text-blue-400" />
              <span>Post Management</span>
            </button>
            <button
              data-testid="tab-about"
              onClick={() => handleTabClick(3)}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center space-x-3 ${
                currentTab === 3 ? 'bg-gray-700' : 'hover:bg-gray-800'
              }`}
            >
              <Info className="w-5 h-5 text-amber-400" />
              <span>About</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Backdrop */}
      {isOpen && (
        <div
          data-testid="menu-backdrop"
          className="fixed inset-0 z-30 bg-black bg-opacity-50"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
