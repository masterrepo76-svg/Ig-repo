import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ImageEditor } from './image-editor';
import { PostPreview, type PostData } from './post-preview';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Camera, Upload, Loader2, ArrowLeft } from 'lucide-react';

type UploadStage = 'welcome' | 'fileSelect' | 'processing' | 'ready' | 'editing' | 'preview';

export function UploadTab() {
  const [stage, setStage] = useState<UploadStage>('welcome');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const publishMutation = useMutation({
    mutationFn: async (postData: PostData) => {
      return apiRequest('POST', '/api/posts', postData);
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Post published successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      resetToWelcome();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to publish post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetToWelcome = () => {
    setStage('welcome');
    setSelectedImage(null);
    setEditedImage(null);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setStage('processing');
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setSelectedImage(imageUrl);
        
        // Simulate processing time
        setTimeout(() => {
          setStage('ready');
        }, 2000);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveEdit = (editedImageUrl: string) => {
    setEditedImage(editedImageUrl);
    setStage('preview');
  };

  const handlePublish = (postData: PostData) => {
    const finalData = {
      ...postData,
      image: editedImage || selectedImage || '',
    };
    publishMutation.mutate(finalData);
  };

  const handleBack = () => {
    switch (stage) {
      case 'fileSelect':
        setStage('welcome');
        break;
      case 'processing':
        // Can't go back during processing
        break;
      case 'ready':
        setStage('fileSelect');
        break;
      case 'editing':
        setStage('ready');
        break;
      case 'preview':
        setStage('ready');
        break;
      default:
        break;
    }
  };

  const showBackButton = stage !== 'welcome' && stage !== 'processing';

  return (
    <div data-testid="upload-tab" className="glass-effect rounded-2xl p-6 lg:p-8 shadow-2xl">
      {showBackButton && (
        <Button
          data-testid="back-button"
          onClick={handleBack}
          variant="ghost"
          className="mb-4 text-white hover:bg-gray-600"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
      )}
      
      <h1 className="text-3xl lg:text-4xl font-bold text-center mb-8 text-white flex items-center justify-center">
        <Upload className="w-8 h-8 text-emerald-400 mr-3" />
        Welcome to Admin Panel
      </h1>

      {/* Welcome Section */}
      {stage === 'welcome' && (
        <div data-testid="welcome-section" className="text-center mb-8">
          <div className="mb-6">
            <div className="w-32 h-32 mx-auto bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
              <Camera className="w-12 h-12 text-white" />
            </div>
            <p className="text-gray-300 text-lg mb-6">Start by uploading your content</p>
          </div>
          <Button
            data-testid="choose-file-button"
            onClick={() => setStage('fileSelect')}
            className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600 text-white px-8 py-4 text-lg font-semibold shadow-lg animate-pulse"
          >
            <Upload className="w-5 h-5 mr-2" />
            Tap to Choose File
          </Button>
        </div>
      )}

      {/* File Selection */}
      {stage === 'fileSelect' && (
        <div data-testid="file-selector" className="mb-6">
          <div className="border-2 border-dashed border-gray-500 rounded-xl p-8 text-center hover:border-blue-400 transition-colors">
            <input
              data-testid="file-input"
              type="file"
              id="imageInput"
              accept="image/*"
              className="hidden"
              onChange={handleFileSelect}
            />
            <label htmlFor="imageInput" className="cursor-pointer">
              <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-white text-xl font-semibold mb-2">Choose File Preview</p>
              <p className="text-gray-400">Click here or drag and drop your image</p>
            </label>
          </div>
        </div>
      )}

      {/* Processing Animation */}
      {stage === 'processing' && (
        <div data-testid="processing-section" className="text-center py-8">
          <Loader2 className="w-16 h-16 animate-spin mx-auto mb-4 text-blue-500" />
          <p className="text-white text-xl font-semibold">Processing Your Image...</p>
          <p className="text-gray-400">Please wait while we prepare your image for editing</p>
        </div>
      )}

      {/* Image Ready - Choose Edit or Continue */}
      {stage === 'ready' && selectedImage && (
        <div data-testid="image-ready-section" className="text-center">
          <div className="bg-gray-700 rounded-xl p-6 mb-6">
            <h3 className="text-xl font-semibold text-white mb-4">Your Image is Ready!</h3>
            <img
              src={selectedImage}
              alt="Uploaded Image"
              className="max-w-full h-64 object-contain mx-auto rounded mb-6"
            />
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                data-testid="continue-without-edit"
                onClick={() => setStage('preview')}
                className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-lg"
              >
                Continue Without Edit
              </Button>
              <Button
                data-testid="edit-image"
                onClick={() => setStage('editing')}
                className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 text-lg"
              >
                Edit Image
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Image Editing Section */}
      {stage === 'editing' && selectedImage && (
        <ImageEditor
          imageUrl={selectedImage}
          onSave={handleSaveEdit}
          onCancel={resetToWelcome}
        />
      )}

      {/* Post Preview Section */}
      {stage === 'preview' && (editedImage || selectedImage) && (
        <PostPreview
          imageUrl={editedImage || selectedImage!}
          onPublish={handlePublish}
        />
      )}
    </div>
  );
}
