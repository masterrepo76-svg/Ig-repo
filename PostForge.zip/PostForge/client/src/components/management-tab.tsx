import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { PASSWORD } from '@/lib/supabase';
import type { Post } from '@shared/schema';
import { Lock, CheckCircle, Trash2, Eye, Check, X, Key, Clock } from 'lucide-react';

export function ManagementTab() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [password, setPassword] = useState('');
  const [previewPost, setPreviewPost] = useState<Post | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts = [], isLoading } = useQuery<Post[]>({
    queryKey: ['/api/posts'],
    enabled: isUnlocked,
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id, approved }: { id: string; approved: boolean }) => {
      return apiRequest('PATCH', `/api/posts/${id}/approval`, { approved });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({
        title: "Success",
        description: "Post status updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update post status",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest('DELETE', `/api/posts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({
        title: "Success",
        description: "Post deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive",
      });
    },
  });

  const handlePasswordSubmit = () => {
    if (password === PASSWORD) {
      setIsUnlocked(true);
      toast({
        title: "Access Granted",
        description: "Welcome to post management",
      });
    } else {
      toast({
        title: "Access Denied",
        description: "Incorrect password",
        variant: "destructive",
      });
      setPassword('');
    }
  };

  const formatTimeAgo = (date: Date | null) => {
    if (!date) return 'Unknown time';
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return 'Just now';
    if (diffHours === 1) return '1 hour ago';
    return `${diffHours} hours ago`;
  };

  return (
    <div data-testid="management-tab" className="glass-effect rounded-2xl p-6 lg:p-8 shadow-2xl">
      {!isUnlocked ? (
        /* Password Protection */
        <div data-testid="password-section">
          <div className="text-center mb-8">
            <div className="w-24 h-24 mx-auto bg-red-500 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">Secure Access Required</h2>
            <p className="text-gray-300">Enter Access Code</p>
          </div>

          <div className="max-w-md mx-auto">
            <Input
              data-testid="password-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password..."
              className="w-full p-4 bg-gray-700 text-white text-center text-xl rounded-xl border-gray-500 focus:border-blue-400 mb-4"
              maxLength={12}
              onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
            />
            <Button
              data-testid="unlock-button"
              onClick={handlePasswordSubmit}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 text-lg font-semibold"
            >
              <Key className="w-5 h-5 mr-2" />
              Unlock Access
            </Button>
          </div>
        </div>
      ) : (
        /* Post Management */
        <div data-testid="post-management">
          <div className="text-center mb-8">
            <div className="w-24 h-24 mx-auto bg-emerald-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Access Granted</h2>
            <p className="text-gray-300">Manage your posts below</p>
          </div>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-white">Loading posts...</p>
            </div>
          ) : posts.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 text-lg">No posts found</p>
            </div>
          ) : (
            <div data-testid="posts-list" className="space-y-4">
              {posts.map((post: Post) => (
                <div
                  key={post.id}
                  data-testid={`post-item-${post.id}`}
                  className="bg-gray-700 rounded-xl p-6 border border-gray-600"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                    <div className="flex items-start space-x-4">
                      <img
                        data-testid={`post-image-${post.id}`}
                        src={post.image}
                        alt="Post Image"
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div>
                        <h4 className="text-white font-semibold mb-1">
                          {post.description.length > 30 
                            ? `${post.description.substring(0, 30)}...` 
                            : post.description}
                        </h4>
                        <p className="text-gray-300 text-sm mb-2">
                          {post.description.length > 50 
                            ? `${post.description.substring(0, 50)}...` 
                            : post.description}
                        </p>
                        <p className="text-emerald-400 font-bold text-lg">₦{post.price}</p>
                        <p className="text-gray-500 text-xs mt-1 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatTimeAgo(post.createdAt)}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button
                        data-testid={`approve-${post.id}`}
                        onClick={() => approveMutation.mutate({ id: post.id, approved: true })}
                        disabled={Boolean(post.approved)}
                        className="bg-emerald-500 hover:bg-emerald-600 text-white text-sm"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        {post.approved ? 'Approved' : 'Approve for Website'}
                      </Button>
                      <Button
                        data-testid={`delete-${post.id}`}
                        onClick={() => deleteMutation.mutate(post.id)}
                        variant="destructive"
                        className="text-sm"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete Permanently
                      </Button>
                      <Button
                        data-testid={`preview-${post.id}`}
                        onClick={() => setPreviewPost(post)}
                        className="bg-blue-500 hover:bg-blue-600 text-white text-sm"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Post Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Preview Modal */}
      <Dialog open={!!previewPost} onOpenChange={() => setPreviewPost(null)}>
        <DialogContent data-testid="preview-modal" className="max-w-2xl bg-gray-800 text-white">
          <DialogHeader>
            <DialogTitle>Post Preview</DialogTitle>
          </DialogHeader>

          {previewPost && (
            <div className="space-y-6">
              {/* Facebook-style preview */}
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-4 border-b">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <i className="fas fa-store text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Your Store</h4>
                      <p className="text-sm text-gray-500">{formatTimeAgo(previewPost.createdAt)}</p>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <p className="text-gray-800 mb-2">{previewPost.description}</p>
                  <p className="text-2xl font-bold text-emerald-600 mb-2">₦{previewPost.price}</p>
                  <a
                    href={`https://wa.me/${previewPost.whatsapp.replace('+', '')}?text=${encodeURIComponent(`I LOVE THIS ORDER - ${previewPost.description} - HOW CAN I GET it?`)}`}
                    className="inline-flex items-center text-emerald-600 hover:text-emerald-700 font-medium"
                  >
                    <i className="fab fa-whatsapp mr-2"></i>
                    Contact via WhatsApp
                  </a>
                </div>
                <img
                  src={previewPost.image}
                  alt="Post Preview"
                  className="w-full h-64 object-cover"
                />
              </div>

              <div className="flex space-x-4">
                <Button
                  onClick={() => {
                    approveMutation.mutate({ id: previewPost.id, approved: true });
                    setPreviewPost(null);
                  }}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white flex-1"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Accept
                </Button>
                <Button
                  onClick={() => {
                    deleteMutation.mutate(previewPost.id);
                    setPreviewPost(null);
                  }}
                  variant="destructive"
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-2" />
                  Decline
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
