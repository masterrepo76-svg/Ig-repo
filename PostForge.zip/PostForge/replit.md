# Overview

This is a full-stack admin panel application for managing posts with image upload and approval workflows. The system provides a content management interface where administrators can upload images, edit them with built-in tools, create social media-style post previews with descriptions and pricing information, and manage post approval status. The application features a modern React frontend built with TypeScript and shadcn/ui components, an Express.js backend API, and uses PostgreSQL with Drizzle ORM for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with a custom design system using CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management and API caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

The frontend follows a component-based architecture with clear separation between UI components, business logic hooks, and API interaction layers. The application is structured as a single-page admin panel with tabbed navigation for different functionalities.

## Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database ORM**: Drizzle ORM for type-safe database operations and schema management
- **API Design**: RESTful endpoints following conventional HTTP methods and status codes
- **Error Handling**: Centralized error handling middleware with structured error responses
- **Request Logging**: Custom middleware for API request/response logging with performance metrics

The backend implements a clean separation between route handlers, business logic (storage layer), and database operations. It uses dependency injection patterns for testability and maintainability.

## Data Storage
- **Database**: PostgreSQL as the primary data store
- **Schema Management**: Drizzle Kit for database migrations and schema synchronization
- **Connection**: Neon serverless PostgreSQL for cloud-hosted database with connection pooling
- **Data Validation**: Zod schemas shared between frontend and backend for consistent type safety

The posts table includes fields for image URLs, descriptions, pricing, contact information, approval status, and timestamps. The schema uses UUIDs for primary keys and includes proper indexing for query performance.

## Authentication and Authorization
The application implements a simple password-based authentication system for admin access. The management functionality is protected by a hardcoded password check, suitable for single-admin scenarios. This approach prioritizes simplicity over complex user management for the intended use case.

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling and automatic scaling
- **Connection String**: Configured via DATABASE_URL environment variable for database connectivity

## UI Component Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives for building the component system
- **Lucide React**: Icon library providing consistent iconography throughout the application
- **shadcn/ui**: Pre-built component library combining Radix UI with Tailwind CSS styling

## Image Processing
The application includes a custom image editor component with capabilities for brightness adjustment, rotation, and basic cropping functionality. Image processing is handled client-side using HTML5 Canvas API.

## Development Tools
- **Vite**: Modern build tool with hot module replacement for fast development
- **TypeScript**: Static type checking across the entire application stack
- **ESBuild**: Fast bundling for production builds
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer plugins

## Third-party Integrations
- **WhatsApp**: Direct integration for generating WhatsApp contact links with pre-filled messages
- **Unsplash**: Background image integration for dynamic theme switching
- **Replit**: Development environment integration with specialized plugins for the Replit platform