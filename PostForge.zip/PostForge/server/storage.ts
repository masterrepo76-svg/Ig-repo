import { type Post, type InsertPost, posts } from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool } from "@neondatabase/serverless";
import { eq, desc } from "drizzle-orm";

let db: any;
let pool: any;

// Initialize database connection if DATABASE_URL is available
if (process.env.DATABASE_URL) {
  try {
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    db = drizzle(pool);
  } catch (error) {
    console.warn('Database connection failed, using memory storage:', error);
  }
}

export interface IStorage {
  createPost(post: InsertPost): Promise<Post>;
  getAllPosts(): Promise<Post[]>;
  getPostById(id: string): Promise<Post | undefined>;
  updatePostApproval(id: string, approved: boolean): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async createPost(insertPost: InsertPost): Promise<Post> {
    if (!db) {
      throw new Error('Database not available');
    }
    
    // First ensure the table exists
    try {
      await db.execute(`
        CREATE TABLE IF NOT EXISTS posts (
          id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
          post_id VARCHAR NOT NULL UNIQUE,
          image TEXT NOT NULL,
          description TEXT NOT NULL,
          price INTEGER NOT NULL,
          whatsapp TEXT NOT NULL,
          country_code TEXT NOT NULL,
          phone_number TEXT NOT NULL,
          approved BOOLEAN DEFAULT false,
          created_at TIMESTAMP DEFAULT NOW()
        )
      `);
    } catch (error) {
      console.log('Table might already exist:', error);
    }

    const postId = insertPost.postId || Date.now().toString();
    const postData = {
      ...insertPost,
      postId,
    };

    const [post] = await db.insert(posts).values(postData).returning();
    return post;
  }

  async getAllPosts(): Promise<Post[]> {
    if (!db) {
      throw new Error('Database not available');
    }
    return await db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async getPostById(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }

  async updatePostApproval(id: string, approved: boolean): Promise<Post | undefined> {
    const [post] = await db
      .update(posts)
      .set({ approved })
      .where(eq(posts.id, id))
      .returning();
    return post;
  }

  async deletePost(id: string): Promise<boolean> {
    const result = await db.delete(posts).where(eq(posts.id, id));
    return (result.rowCount || 0) > 0;
  }
}

export class MemStorage implements IStorage {
  private posts: Map<string, Post>;

  constructor() {
    this.posts = new Map();
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const postId = insertPost.postId || Date.now().toString();
    const post: Post = {
      ...insertPost,
      id,
      postId,
      approved: false,
      createdAt: new Date(),
    };
    this.posts.set(id, post);
    return post;
  }

  async getAllPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).sort((a, b) => 
      (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }

  async getPostById(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async updatePostApproval(id: string, approved: boolean): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (post) {
      const updatedPost = { ...post, approved };
      this.posts.set(id, updatedPost);
      return updatedPost;
    }
    return undefined;
  }

  async deletePost(id: string): Promise<boolean> {
    return this.posts.delete(id);
  }
}

// Initialize storage
console.log('DATABASE_URL available:', !!process.env.DATABASE_URL);
console.log('Database connection available:', !!db);

// Use database storage since connection is working
export const storage = new DatabaseStorage();
